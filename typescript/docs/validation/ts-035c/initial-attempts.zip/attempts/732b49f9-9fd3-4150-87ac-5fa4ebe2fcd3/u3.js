"use strict";
assert(false,"beta");