"use strict";
Test262Error.thrower("beta");