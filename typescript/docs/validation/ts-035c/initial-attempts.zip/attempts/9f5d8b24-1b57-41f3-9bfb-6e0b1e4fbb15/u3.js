"use strict";
Test262Error.thrower("control");