"use strict";
assert(false);